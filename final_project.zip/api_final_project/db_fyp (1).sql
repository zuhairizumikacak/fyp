-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2023 at 12:08 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `id` int(11) NOT NULL,
  `admin_email` varchar(150) NOT NULL,
  `admin_name` varchar(200) NOT NULL,
  `admin_number` varchar(25) NOT NULL,
  `admin_password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`id`, `admin_email`, `admin_name`, `admin_number`, `admin_password`) VALUES
(1, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_details`
--

CREATE TABLE `candidate_details` (
  `ic_number` varchar(25) NOT NULL,
  `candidate_name` text NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `candidate_email` varchar(100) NOT NULL,
  `candidate_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate_details`
--

INSERT INTO `candidate_details` (`ic_number`, `candidate_name`, `phone_number`, `candidate_email`, `candidate_address`) VALUES
('0121112919', 'zuhairi', '01928282', 'zuhairi@gmail.com', 'kampung besi'),
('0192331', 'ss', '2323', 'e@gmail.com', 'asdas');

-- --------------------------------------------------------

--
-- Table structure for table `school_details`
--

CREATE TABLE `school_details` (
  `school_id` int(11) NOT NULL,
  `spm_year` varchar(10) NOT NULL,
  `school_name` varchar(250) NOT NULL,
  `school_type` varchar(5) NOT NULL,
  `ic_number` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `spm_details`
--

CREATE TABLE `spm_details` (
  `spm_id` int(11) NOT NULL,
  `subject_name` varchar(150) NOT NULL,
  `subject_grade` text NOT NULL,
  `ic_number` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_details`
--
ALTER TABLE `admin_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_email` (`admin_email`);

--
-- Indexes for table `candidate_details`
--
ALTER TABLE `candidate_details`
  ADD PRIMARY KEY (`ic_number`);

--
-- Indexes for table `school_details`
--
ALTER TABLE `school_details`
  ADD PRIMARY KEY (`school_id`),
  ADD KEY `icnumber` (`ic_number`);

--
-- Indexes for table `spm_details`
--
ALTER TABLE `spm_details`
  ADD PRIMARY KEY (`spm_id`),
  ADD KEY `icnumber1` (`ic_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_details`
--
ALTER TABLE `admin_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `school_details`
--
ALTER TABLE `school_details`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `spm_details`
--
ALTER TABLE `spm_details`
  MODIFY `spm_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `school_details`
--
ALTER TABLE `school_details`
  ADD CONSTRAINT `icnumber` FOREIGN KEY (`ic_number`) REFERENCES `candidate_details` (`ic_number`);

--
-- Constraints for table `spm_details`
--
ALTER TABLE `spm_details`
  ADD CONSTRAINT `icnumber1` FOREIGN KEY (`ic_number`) REFERENCES `candidate_details` (`ic_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
