<?php
include 'connection.php';

if (isset($_POST['ic_number'], $_POST['candidate_name'], $_POST['phone_number'], $_POST['candidate_email'], $_POST['candidate_address'])) {
  $icNumber = $_POST['ic_number'];
  $candidateName = $_POST['candidate_name'];
  $phoneNumber = $_POST['phone_number'];
  $candidateEmail = $_POST['candidate_email'];
  $candidateAddress = $_POST['candidate_address'];

  // Perform the insert query
  $sqlQuery = "INSERT INTO candidate_details (ic_number, candidate_name, phone_number, candidate_email, candidate_address) VALUES ('$icNumber', '$candidateName', '$phoneNumber', '$candidateEmail', '$candidateAddress')";

  if ($connectNow->query($sqlQuery)) {
    echo json_encode(array("success" => true));
  } else {
    echo json_encode(array("success" => false));
  }
} 
