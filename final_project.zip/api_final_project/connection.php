<?php
$serverHost = "localhost";
$user = "root";
$password = "";
$database = "db_fyp";


$connectNow = new mysqli($serverHost, $user, $password, $database); 
