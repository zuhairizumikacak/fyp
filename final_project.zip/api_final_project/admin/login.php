<?php
include '../connection.php';

//POST = send/save data to mysql db
//GET = retrieve/read data from mysql db

$admin_email = $_POST['admin_email'];
$admin_password = $_POST['admin_password'];

$sqlQuery = "SELECT * FROM admin_details WHERE admin_email = '$admin_email' AND admin_password = '$admin_password'";

$resultOfQuery = $connectNow->query($sqlQuery);

if($resultOfQuery->num_rows > 0)
{
    $adminRecord = array();
    while($rowFound = $resultOfQuery->fetch_assoc())
    {
        $adminRecord[] = $rowFound;
    }

    echo json_encode(
        array(
            "success"=>true,
            "adminData"=>$adminRecord[0],
        )
    );
}
else
{
    echo json_encode(array("success"=>false));
}