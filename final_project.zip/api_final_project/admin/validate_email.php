<?php

include '../connection.php';

$admin_email = $_POST['admin_email'];

// Check if the email is in a valid format
if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(array("emailValid" => false, "message" => "Invalid email format."));
    exit();
}

$sqlQuery = "SELECT * FROM admin_details WHERE admin_email = '$admin_email'";
$resultOfQuery = $connectNow->query($sqlQuery);

if ($resultOfQuery->num_rows > 0) {
    echo json_encode(array("emailFound" => true, "message" => "Email already in use."));
} else {
    echo json_encode(array("emailFound" => false));
}
