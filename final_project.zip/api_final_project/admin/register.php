<?php
include '../connection.php';


//POST = send/save data to mysql db
//GET = retrieve/read data from mysql db

$admin_email = $_POST['admin_email'];
$admin_name = $_POST['admin_name'];
$admin_number = $_POST['admin_number'];
$admin_password = $_POST['admin_password'];

$sqlQuery = "INSERT INTO admin_details SET admin_email = '$admin_email', admin_name = '$admin_name', admin_number = '$admin_number', admin_password = '$admin_password'";

$resultOfQuery = $connectNow->query($sqlQuery);

if($resultOfQuery)
{
    echo json_encode(array("success"=>true));
}
else
{
    echo json_encode(array("success"=>false));
}