<?php
include 'connection.php';

if (isset($_POST['ic_number'], $_POST['school_name'], $_POST['school_type'], $_POST['spm_year'])) {
$icNumber = $_POST['ic_number'];
$school_name = $_POST['school_name'];
$school_type = $_POST['school_type'];
$spm_year = $_POST['spm_year'];


$sqlQuery = "INSERT INTO school_details SET school_name = '$school_name', school_type = '$school_type', spm_year = '$spm_year'";

if ($connectNow->query($sqlQuery)) {
    echo json_encode(array("success" => true));
  } else {
    echo json_encode(array("success" => false));
  }

}

